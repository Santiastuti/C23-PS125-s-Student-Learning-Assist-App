# License

This project is licensed under the [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-nc-sa/4.0/).  

It basically means you can do whatever you want with it as long as it's for non-commercial use but you've got to attribute the original author ([sbmsr](http://github.com/sbmsr)) and share any derivative works under the same license.

If you're interested in using our projects for commercial purposes or otherwise licensing material, feel free to get in touch at [founders@jobsimulator.dev](mailto:founders@jobsimulator.dev).
