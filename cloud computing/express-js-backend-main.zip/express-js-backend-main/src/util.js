const jwt = require('jsonwebtoken');

const getSecretKey = () => {
    const secretKey = process.env.SECRET_KEY || "abcdefg";
    return secretKey;
}

const authenticateJWT = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (authHeader) {
        const token = authHeader.split(' ')[1];
        jwt.verify(token, getSecretKey(), (err, user) => {
            if (err) {
                return res.sendStatus(403);
            }
            req.user = user;
            next();
        });
    } else {
        res.sendStatus(401);
    }
};

module.exports = {
    getSecretKey, authenticateJWT
}