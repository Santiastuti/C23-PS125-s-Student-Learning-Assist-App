const express = require("express");
const router = express.Router();
const { query } = require("../db.js");
const { authenticateJWT } = require("../util.js");
const { body, validationResult } = require('express-validator');

// (C) Create Data Master 
router.post("/", [
    authenticateJWT,
    body('title').notEmpty(),
    body('description').notEmpty(),
], async function (req, res, next) {
    // Validation
    const errors = validationResult(req).formatWith(({ msg }) => { return msg; });
    if (!errors.isEmpty()) {
        return res.status(422).json({
            status: false,
            message: errors.mapped()
        });
    }

    // Mapping parameter to variable
    const title = req.body?.title;
    const description = req.body?.description;

    // Insert data to Database
    const sql = `
            INSERT INTO learning_recommendations (title, description) VALUES ('${title}', '${description}');
        `;
    const result = await query(sql);
    const response = {
        data: {
            result
        },
        message: "berhasil menambahkan data",
    }
    return res.status(200).json(response);
});

// Log History Quiz Transaction
router.post("/quiz", [
    authenticateJWT,
    body('answer').notEmpty(),
], async function (req, res, next) {
    // Validation
    const errors = validationResult(req).formatWith(({ msg }) => { return msg; });
    if (!errors.isEmpty()) {
        return res.status(422).json({
            status: false,
            message: errors.mapped()
        });
    }

    // Mapping parameter to variable
    const answer = req.body?.answer;
    const user_id = 1;

    // Machine Learning API
    const axios = require('axios');
    const data = JSON.stringify({
        "text": answer
    });
    const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://api-app-mrsltgtoaa-et.a.run.app/predict_text',
        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };
    axios.request(config)
        .then(async (response) => {
            // Log data to Database
            const prediction_result = response.data;
            const sql = `
                INSERT INTO t_learning_recommendations (answer, user_fk, prediction_result) VALUES ('${answer}', '${user_id}', '${prediction_result}');
            `;
            const result = await query(sql);
            return res.status(200).json({
                data: {
                    result
                },
                message: "berhasil menambahkan data log",
            });
        })
        .catch((error) => {
            console.log(error);
            res.status(400).send("Terjadi kesalahan pada API Machine Learning !");
        });
});

// (R) Read Data Master 
router.get("/", [
    authenticateJWT,
], async function (req, res, next) {
    // Select data from Database
    const sql = `
        SELECT * FROM learning_recommendations
    `;
    const result = await query(sql);
    const response = {
        data: {
            result
        },
        message: "berhasil mengambil data",
    }
    return res.status(200).json(response);
});

// (R) Read Data Master by ID
router.get("/:id", [
    authenticateJWT,
], async function (req, res, next) {
    // Select data from Database
    const id = req.params.id;
    const sql = `
        SELECT * FROM learning_recommendations
        WHERE id = '${id}'
    `;
    const result = await query(sql);
    let response;
    if (result.length != 0) {
        response = {
            data: {
                result
            },
            message: "berhasil mengambil data dengan id " + id,
        }
        return res.status(200).json(response);
    }
    else {
        response = {
            message: "data dengan id " + id + " tidak ditemukan",
        }
        return res.status(404).json(response);
    }
});

// (U) Update Data Master 
// router.put("/", async function (req, res, next) {
//     // TODO
// });

// (D) Delete Data Master 
router.delete("/", [
    authenticateJWT,
    body('id').notEmpty(),
], async function (req, res, next) {
    // Validation
    const errors = validationResult(req).formatWith(({ msg }) => { return msg; });
    if (!errors.isEmpty()) {
        return res.status(422).json({
            status: false,
            message: errors.mapped()
        });
    }
    
    // Mapping parameter to variable
    const id = req.body.id;

    // Insert data to Database
    const sql = `
      DELETE FROM learning_recommendations
      WHERE id = '${id}'
  `;
    const result = await query(sql);
    const response = {
        data: {
            result
        },
        message: "berhasil menghapus data dengan id " + id,
    }
    return res.status(200).json(response);
});

module.exports = router;
