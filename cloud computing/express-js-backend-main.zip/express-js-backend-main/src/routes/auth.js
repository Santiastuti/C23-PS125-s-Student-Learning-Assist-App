const express = require("express");
const jwt = require('jsonwebtoken');
const hash = require('object-hash');
const router = express.Router();

const { query } = require("../db.js");
const { getSecretKey } = require("../util.js");
const { body, validationResult } = require('express-validator');

// Config Upload File from Form Data
const multer = require('multer');
const upload = multer({
    dest : 'uploads/',
});

router.post("/login", [
    body('email').notEmpty(),
    body('password').notEmpty(),
],async function (req, res, next) {
    // Validation
    const errors = validationResult(req).formatWith(({ msg }) => { return msg; });
    if (!errors.isEmpty()) {
        return res.status(422).json({
            status: false,
            message: errors.mapped()
        });
    }
    
    // Mapping parameter to variable
    const email = req.body?.email;
    const password = hash(req.body?.password);

    // Check email login data and password
    const users = await query(`
        SELECT id, email, password FROM users
        WHERE email = '${email}'
    `);
    if(users.length == 0) {
        res.status(400).json({
            message: `akun login tidak valid` 
        });
        return;
    }

    // Check whether the password is correct
    const passwordUser = users[0]["password"];
    if(password != passwordUser) {
        res.status(400).json({
            message: `akun login tidak valid` 
        });
        return;
    }

    // Login successful, generate access token
    const token = jwt.sign({email}, getSecretKey());
    const response = {
        data: {
            email, token
        },
        message: "berhasil login",
    }
    res.status(200).json(response);
    return;
});

router.post("/register", [
    upload.single('photo_profile'),
    body('name').notEmpty(),
    body('email').notEmpty(),
    body('password').notEmpty(),
], async function (req, res, next) {
    // Validation
    const errors = validationResult(req).formatWith(({ msg }) => { return msg; });
    if (!errors.isEmpty()) {
        return res.status(422).json({
            status: false,
            message: errors.mapped()
        });
    }

    // Mapping parameter to variable
    const name = req.body?.name;
    const email = req.body?.email;
    const password = hash(req.body?.password);
    
    // Validation if email is already used
    const users = await query(`
        SELECT id FROM users WHERE email = '${email}'
    `);
    if(users.length > 1) {
        res.status(400).json({
            message: `${email} sudah digunakan !!` 
        });
        return;
    }
    
    // Execute Database Insert New Data to Users Tables
    const data = await query(`
        INSERT INTO users (email, name, password) VALUES ('${email}', '${name}', '${password}')
    `);

    const response = {
        name, 
        email, 
        password, 
        data, 
    };

    res.status(200).json(response);
    return;
});

module.exports = router;