const express = require("express");
const router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  const response = {
    message: "welcome to express-js-backend gateway",
  }
  res.status(200).json(response);
});

module.exports = router;
