package com.example.sias.ui.learning


import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class LearningViewModel : ViewModel() {

    private val _text = MutableLiveData<String>()
}